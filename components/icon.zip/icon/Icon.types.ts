import { IconType } from './../../types/enums';
export interface IIconProps {
  iconName: IconType;
}
